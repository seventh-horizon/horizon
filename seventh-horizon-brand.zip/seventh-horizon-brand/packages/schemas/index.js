// seventh-horizon-brand/packages/schemas/index.js
import schema from './token-schema.json' assert { type: 'json' };

export const themeTokensSchema = schema;
export default { themeTokensSchema: schema };