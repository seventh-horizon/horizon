# Seventh Horizon — Brand (DreamB)
Source of truth for brand manifests (tokens, motion, tone) and schemas.
