CI stubs for brand verification/publish will live here (Cycle 4).
