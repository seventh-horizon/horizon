// Vitest-only setup. Keep this file small and DO NOT import it from Playwright.
