import { test, expect } from '@playwright/test';

// Verifies that clicking the toolbar "Filters" (open-drawer) button opens the drawer
// This matches the app's end-to-end environment used by your other Playwright tests.

test('toolbar Filters button opens the drawer', async ({ page }) => {
  // Visit the app root (uses baseURL from playwright.config.ts if set)
  await page.goto('/');

  // Find the drawer opener by stable data-test hook
  const opener = page.locator('[data-test="open-drawer"]').first();
  await expect(opener).toBeVisible();
  await opener.click();

  await page.waitForSelector('[data-test="drawer"].open, [data-test="drawer"]:visible', { timeout: 3000 });
  const drawer = page.locator('[data-test="drawer"]');
  await expect(drawer).toBeVisible();
});
